
<?php 

include 'actionComment.php';
 ?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="javascript" href="bootstrap/js/bootstrap.min.js">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css">
 	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/v4-shims.css">
 	<link rel="stylesheet" type="text/css" href="css/menustyle.css">
 	<link rel="stylesheet" type="text/css" href="datatables/datatables.min.css"/>
</head>
<body>
	<!--NAVBAR-->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#"><img src="images/mommy.png" style="height: 70px;">MOMMYS TUMMY</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto w-100 justify-content-end sticky-top">
       <li class="nav-item">
        <a class="nav-link" style="color: " href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link"  href="UserMenu.php">Menu</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" style="color: green" href="contact.php">Contact</a>
      </li>
      <li class="nav-item">
          <a class="nav-link" href="cart.php"><i class="fas fa-shopping-cart"></i> <span id="cart-item" class="badge badge-danger"></span></a>
        </li>
     
  </div>
</nav>
<!--BANNER-->
<div class="banner1">
  <img src="images/bann.png">
</div>

<center>

<div class="social">
<a href="https://www.google.com/maps/dir//MOMMY'S+TUMMY+RESTAURANT+location/@16.0521591,120.3128746,12z/data=!3m1!4b1!4m9!4m8!1m1!4e2!1m5!1m1!1s0x3391694535c7ee0d:0x50532f20353167f8!2m2!1d120.3829151!2d16.0521705"><i class="fas fa-search-location" style="color: red"></i></a>
<a href="https://www.facebook.com/mommystummy/"><i class="fab fa-facebook-f" style="color: red"></i></a>
 <a href="https://www.instagram.com/mommystummy/?hl=en"><i class="fab fa-instagram" style="color: red"></i></a>

</div>



</center>
	</header>   
	<div class="section">
		<div class="container">
			<div class="content-section">
				<div class="title">
					<h1>Mommys Tummy Resturant</h1>
					<h4>Anolid Highway Mangaldan, Pangasinan</h4>
					<br>
				</div>
				<div class="content">
					
					<p>Greetings! We, the undersigned 3rd Year College BSIT students from PHINMA 
					University of Pangasinan presently conducting a research study entitled “Online 
					Ordering System for Mommy’s Tummy Restaurant”. This study aims to develop a 
					Web Based Online Ordering System for Mommy’s Tummy Restaurant. 
					The proponents proposed an Online Ordering System to give the Mommy’s Tummy 
					Restaurant the ability to increase their sales and promote their products.</p>


				
										<!-- <div class="button">	
								<a href="#">Read More</a>
						</div>	 -->
				</div>
					
			</div>
			<div class="image-section">	
					<img src="images/aboutimg.png ">
			</div>

      <div style="margin-top: 420px;">
      <center>
      
      <div class="col-lg-6 bg-light rounded mt-4  ">
        <h4 class="text-center p-2"><ce>Write your comment</h4>
        <form action="contact.php" method="POST" class="p-2">
          <div class="form-group"><br>
            <input type="text" name="name" class="form-control rounded-0" placeholder="Enter your Name:" required>
          </div>
          <div class="form-group">
            <textarea name="comment" class="form-control rounded-0" placeholder="Write your comment here" required></textarea></div>

            <div class="form-group"><br>
              <input type="submit" name="submit" class="btn btn-primary rounded-0" value="Post Comment">

            <h5 class="float-right text-success p-2"><?= $msg; ?></h5>    
          </div>
        </form>
        </div>
      </div>
    </center>
  </div>

      <div class="sample">

      <div style="color: red" ><br>
      <center><h2>Comment list</h2></center>
      <br></div>
      <br>
      

          <?php

          $sql="SELECT * FROM  comment_table ORDER BY id DESC";
          $result=$conn->query($sql);
            while ($row=$result->fetch_assoc()){
            ?>
            <center>
          <div class="card mb-3 border-secondary col-lg-5 bg-secondary">
            <div>
            <div class=" bg-secondary  text-light"
              <span class="font-italic">Posted By:<?=$row['name']?></span><br>
              
              <span class="font-italic">Comment:<?=$row['comment']?></span><br>

              <span class="font-italic">Date:<?=$row['cur_date']?></span><br>
            </div>
            
          </div>
          
        </div>
      <?php }?>
      </div>
        
      </div>





          <div class="social">
            <center>
          <a href="https://www.facebook.com/mommystummy/"><i class="fab fa-facebook-f"></i></a>
          <a href="https://www.twitter.com/"><i class="fab fa-twitter"></i></a>
          <a href="https://www.instagram.com/mommystummy/?hl=en"><i class="fab fa-instagram"></i></a>
        </div>
        <!--FOOTER-->
<footer>
  <div class="container-fluid padding">
    <div class="row text-center">
      <div class="col-md-4">
        <hr class="light">
        <h5>Contacts</h5>
        <hr class="light">
        <p>(+63)927-016-1988</p>
        <p>abcdefhijk@gmail.com</p>
      </div>
      <div class="col-md-4">
        <hr class="light">
        <h5>Operating Hours</h5>
        <hr class="light">
        <p>MON - FRI : 8:00 AM-5:00 PM</p>
        <p>SAT - SUN : 9:00 AM-4:00 PM</p>
      </div>
      <div class="col-md-4">
        <hr class="light">
        <h5>Home Area</h5>
        <hr class="light">
        <p>Anolid Highway</p>
        <p>Mangaldan Pangasinan</p>
      </div>
      <div class="col-12">
        <hr class="light-100">
        <h5>&copy;mommystummy.com</h5>
      </div>
    </div>
  </div>
</footer> 
		</div>
		 <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js'></script>

  <script type="text/javascript">
  $(document).ready(function() {

    // Change the item quantity
    $(".itemQty").on('change', function() {
      var $el = $(this).closest('tr');

      var pid = $el.find(".pid").val();
      var pprice = $el.find(".pprice").val();
      var qty = $el.find(".itemQty").val();
      location.reload(true);
      $.ajax({
        url: 'action.php',
        method: 'post',
        cache: false,
        data: {
          qty: qty,
          pid: pid,
          pprice: pprice
        },
        success: function(response) {
          console.log(response);
        }
      });
    });

    // Load total no.of items added in the cart and display in the navbar
    load_cart_item_number();

    function load_cart_item_number() {
      $.ajax({
        url: 'action.php',
        method: 'get',
        data: {
          cartItem: "cart_item"
        },
        success: function(response) {
          $("#cart-item").html(response);
        }
      });
    }
  });
  </script>
	</div>
</body>
</html>

