<?php
	$conn = new mysqli("localhost","root","","onlineordering");
	if($conn->connect_error){
		die("Connection Failed!".$conn->connect_error);
	}
?>