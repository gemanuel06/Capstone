<!DOCTYPE html>
<html>
<head>
	<title>About us</title>
	<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="javascript" href="bootstrap/js/bootstrap.min.js">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css">
 	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/v4-shims.css">
 	<link rel="stylesheet" type="text/css" href="css/menustyle.css">
 	<link rel="stylesheet" type="text/css" href="datatables/datatables.min.css"/>
</head>
<body>
	<!--NAVBAR-->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">MOMMYS TUMMY</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto w-100 justify-content-end sticky-top">
      <li class="nav-item">
        <a class="nav-link " href="index.php">Menu</a>
      </li>
  <li class="nav-item">
          <a class="nav-link" href="cart.php"><i class="fas fa-shopping-cart"></i> <span id="cart-item" class="badge badge-danger"></span></a>
        </li>
     
     
      <li class="nav-item">
        <a class="nav-link" style="color: green" href="aboutUs.php">About us</a>
      </li>
  </div>
</nav>
<!--BANNER-->

	</header>   
	<div class="section">
		<div class="container">
			<div class="content-section">
				<div class="title">
					<h1>Mommys Tummy Resturant</h1>
					<h4>Anolid Highway Mangaldan, Pangasinan</h4>
					<br>
				</div>
				<div class="content">
					
					<p>Greetings! We, the undersigned 3rd Year College BSIT students from PHINMA 
					University of Pangasinan presently conducting a research study entitled “Online 
					Ordering System for Mommy’s Tummy Restaurant”. This study aims to develop a 
					Web Based Online Ordering System for Mommy’s Tummy Restaurant. 
					The proponents proposed an Online Ordering System to give the Mommy’s Tummy 
					Restaurant the ability to increase their sales and promote their products.</p>
					<div class="social">
					<a href="https://www.facebook.com/mommystummy/"><i class="fab fa-facebook-f"></i></a>
					<a href="https://www.twitter.com/"><i class="fab fa-twitter"></i></a>
					<a href="https://www.instagram.com/mommystummy/?hl=en"><i class="fab fa-instagram"></i></a>
				</div>
				
										<div class="button">	
								<a href="#">Read More</a>
						</div>	
				</div>
					
			</div>
			<div class="image-section">	
					<img src="images/aboutimg.png ">
			</div>
		</div>
		 <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js'></script>

  <script type="text/javascript">
  $(document).ready(function() {

    // Change the item quantity
    $(".itemQty").on('change', function() {
      var $el = $(this).closest('tr');

      var pid = $el.find(".pid").val();
      var pprice = $el.find(".pprice").val();
      var qty = $el.find(".itemQty").val();
      location.reload(true);
      $.ajax({
        url: 'action.php',
        method: 'post',
        cache: false,
        data: {
          qty: qty,
          pid: pid,
          pprice: pprice
        },
        success: function(response) {
          console.log(response);
        }
      });
    });

    // Load total no.of items added in the cart and display in the navbar
    load_cart_item_number();

    function load_cart_item_number() {
      $.ajax({
        url: 'action.php',
        method: 'get',
        data: {
          cartItem: "cart_item"
        },
        success: function(response) {
          $("#cart-item").html(response);
        }
      });
    }
  });
  </script>
	</div>
</body>
</html>



