<?php 
require_once 'php/loginprocess.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="javascript" href="bootstrap/js/bootstrap.min.js">
</head>
<style type="text/css">
body{
	background:url('images/bgimage1.png');
   	background-repeat: no-repeat;
	background-position: center center;
	background-attachment: fixed;
	background-size: cover;
	font-family: "Trebuchet MS", Helvetica, sans-serif
}
.top1{
	margin-top: 140px;
}
.new{
	color: white;
}
</style>
<body>

<div class="container top1">
	<div class="row">
		<div class="col-sm-6">
			<img src="images/aboutimg.png">
		</div>
		<div class="col-sm-6 new">
			<form method="POST">
				<h2>Welcome Admin</h2>
				<div class="form-group">
					<label for="#adminuser">Username</label>
					<input type="text" class="form-control" id="adminuser" name="adminuser" required>
				</div>
				<div class="form-group">
					<label for="#adminpass">Password</label>
					<input type="password" class="form-control" id="adminpass" name="adminpass" required>
				</div>
					<input type="submit" class="btn btn-primary" value="Log In" name="login">
			</form>
		</div>
	</div>
</div>

</body>
</html>