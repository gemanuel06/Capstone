<?php
session_start();



if (isset($_SESSION['email'])) {
	$session_user = $_SESSION['email'];
 
  
	 
               
}


else{
		header('Location:UserMenu.php');
}
session_destroy();

header('Location:UserLogin.php');
?>