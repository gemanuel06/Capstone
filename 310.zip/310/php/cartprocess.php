<?php

$mysqli = new mysqli('localhost','root','','onlineordering') or die(mysqli_error($mysqli));

if (isset($_POST['addmenu']))
{

	$id =$_POST['item_id'];  
	$item_name =$_POST['hidden_name'];
	$hidden_price =$_POST['item_price'];
	$quantity =$_POST['item_quantity'];
	

	$mysqli->query("INSERT INTO cart_item (item_id,hidden_name,item_price,item_quantity) VALUES('$id','$item_name','$hidden_price','$quantity')") or die($mysqli->error);



?>