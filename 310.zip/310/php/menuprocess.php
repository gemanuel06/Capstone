<?php

$mysqli = new mysqli('localhost','root','','onlineordering') or die(mysqli_error($mysqli));

if (isset($_POST['addmenu']))
{
	$product_image=$_FILES['product_image']['name'];
	$product_name=$_POST['product_name'];
	$category=$_POST['category'];
	$product_price=$_POST['product_price'];
	$target="images/".basename($_FILES['product_image']['name']);

	$mysqli->query("INSERT INTO product(product_image,product_name,category,product_price) VALUES('$product_image','$product_name','$category','$product_price')") or die($mysqli->error);

	if (move_uploaded_file($_FILES['']['name'], $target)) {
			echo "";
		}

	header("location: menu.php");

}
if (isset($_POST['updatemenu']))
{
	$id=$_POST['updateid'];
	$product_image=$_FILES['product_image']['name'];
	$product_name=$_POST['product_name'];
	$category=$_POST['category'];
	$product_price=$_POST['product_price'];
	$target="images/".basename($_FILES['product_image']['name']);

	$mysqli->query("UPDATE product SET product_image='$product_image', product_name='$product_name',category='$category',product_price='$product_price' WHERE id=$id") or die($mysqli->error);

}

if (isset($_POST['deletemenu']))
{
	$deleteid=$_POST['deleteid'];
	$mysqli->query("DELETE FROM product WHERE id=$deleteid") or die($mysqli->error());

}

?>