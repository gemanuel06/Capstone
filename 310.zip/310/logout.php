<?php
session_start();

if (isset($_SESSION['adminuser'])) {
	$session_user = $_SESSION['adminuser'];
 
  
	 
               
}


else{
		header('Location:login.php');
}
session_destroy();
header('Location:login.php');
?>